# Utility Meters

Processes readings for utility meters (water, electricity, gas).

## Workflow
Admins log monthly sub-meter readings. The billing engine calculates the charges based on per-unit rates configured in the `meter_rates` table and posts them directly to the unit's ledger.
