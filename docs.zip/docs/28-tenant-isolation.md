# Tenant Isolation

Enforces absolute boundaries between housing societies.

## Implementation Details
Every query execution derives filters from `getTenantScoping()`.

```sql
-- Example generated sql under the hood:
SELECT * FROM units WHERE tenant_id = ? AND block_id = ?;
-- The tenant_id parameter is populated strictly from the validated session context.
```

Client-side requests cannot override `tenant_id` parameters directly, eliminating cross-tenant boundary hops.
