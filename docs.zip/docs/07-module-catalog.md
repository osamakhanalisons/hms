# Module Catalog

All active feature areas are registered inside the platform module registry.

| Module Key | Route | API Source | Database Tables | Target Roles | Status |
|---|---|---|---|---|---|
| `platform` | `/platform` | `platform.ts` | `module_registry`, `tenant_modules` | `super_admin` | IMPLEMENTED |
| `property` | `/property` | `property.ts` | `societies`, `blocks`, `buildings`, `units` | `society_admin` | IMPLEMENTED |
| `residents` | `/residents` | `residents.ts` | `residents`, `resident_vehicles` | `society_admin` | IMPLEMENTED |
| `ledger` | `/ledger` | `ledger.ts` | `charge_heads`, `ledger_entries` | `finance_head`, `resident` | IMPLEMENTED |
| `payments` | `/payments` | `payments.ts` | `payments`, `wallets` | `finance_head`, `resident` | IMPLEMENTED |
| `complaints` | `/complaints` | `complaints.ts` | `complaints`, `complaint_comments` | `resident`, `technician` | IMPLEMENTED |
| `visitor` | `/visitor` | `visitor.ts` | `visitor_passes`, `entry_exit_log` | `resident`, `guard` | IMPLEMENTED |
| `parking` | `/parking` | `parking.ts` | `parking_slots`, `parking_allocations` | `security_head`, `resident` | IMPLEMENTED |
| `utility_meters` | `/utility-meters`| `utility-meters.ts` | `meter_rates`, `meter_readings` | `maintenance_head` | IMPLEMENTED |
| `notice_board` | `/notices` | `notices.ts` | `notices`, `notice_reads` | `society_admin`, `resident` | IMPLEMENTED |
| `community_forum`| `/forum` | `community.ts` | `forum_threads`, `forum_replies` | `resident` | IMPLEMENTED |
| `polls` | `/polls` | `community.ts` | `polls`, `poll_votes` | `resident`, `society_admin` | IMPLEMENTED |
| `events` | `/events` | `community.ts` | `events`, `event_rsvps` | `resident`, `society_admin` | IMPLEMENTED |
| `amenities` | `/amenities` | `community.ts` | `amenities`, `amenity_bookings` | `resident`, `society_admin` | IMPLEMENTED |
| `documents` | `/documents` | `documents.ts` | (Filesystem storage metadata) | All Users | IMPLEMENTED |
| `vendors` | `/vendors` | `vendors.ts` | `vendors`, `rfqs`, `vendor_invoices` | `maintenance_head` | PARTIALLY IMPLEMENTED |
| `inventory` | `/inventory` | `inventory.ts` | `inventory_items`, `stock_movements` | `maintenance_head` | PARTIALLY IMPLEMENTED |
| `projects` | `/projects` | `projects.ts` | `projects`, `project_milestones` | `society_admin` | PARTIALLY IMPLEMENTED |
| `ai_maintenance` | `/ai-maintenance`| `ai-maintenance.ts`| `ai_maintenance_analyses` | `maintenance_head` | PARTIALLY IMPLEMENTED |
