# API Catalog

List of primary Vinxi server function endpoints.

- `getCurrentUserFn`: GET — Resolves user session context.
- `getTenantUsersFn`: GET — Retrieves users filtered by active society.
- `createTenantUserFn`: POST — Validates and creates a new occupant profile.
- `getPropertyTreeFn`: GET — Returns the multi-level property hierarchy.
- `getActiveModulesFn`: GET — Lists enabled modules for the tenant.
