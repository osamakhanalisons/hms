# Payments

This module processes payment entries logged against invoices.

## Status Markers
- **Pending**: Payment is created but not approved by the finance manager.
- **Paid**: Payment is approved, and the matching amount is credited to the unit's ledger balance.

## Gateway Integration Status
- **Current implementation**: **PARTIALLY IMPLEMENTED / MOCKED**. Stripe cards and buttons are present on the frontend, but actual bank/credit card transactions do not occur. Payment records are logged manually by managers.
