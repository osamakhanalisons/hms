# Security Architecture

HousingOS is fortified against data leakage and injection attacks.

## Core Controls

### 1. IDOR Prevention
- Primary keys are randomly generated UUIDs.
- Object fetches must match the tenant ID stored in the user's session context.

### 2. Multi-Society Isolated Scoping
- In all-societies mode, the Super Admin dropdown displays custom roles with their tenant name attached so identical names are not confusing.

### 3. Executable File Blockade
- Restricts document uploads strictly to non-executable extensions (.pdf, .jpg, .png, .xlsx) to prevent code injections.
