# Assets

Tracks capital assets (pumps, generators, elevators) owned by the housing society.

## Preventative Schedules
Assets can be linked to preventative maintenance schedules. If a work order is generated, the asset ID is attached to maintain a historical log of replacement parts and repairs.
