# Frontend Navigation

Visual layout tree of routes based on active role scopes.

- **Super Admin**: `/societies`, `/analytics`, `/audit-log`, `/settings`, `/platform`
- **Society Admin**: `/property`, `/residents`, `/complaints`, `/visitor`, `/maintenance`, `/ledger`, `/settings`
- **Resident**: `/ledger` (locked), `/payments`, `/complaints` (own only), `/visitor` (own only), `/forum`, `/polls`
