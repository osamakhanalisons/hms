# Billing & Ledger

Handles monthly dues, maintenance invoices, and billing ledgers.

## Process Flow

```mermaid
graph TD
    Setup[Admin sets up Charge Heads] --> Gen[Gen invoices for period]
    Gen --> Post[Debit posted to Unit Ledger]
    Post --> View[Resident views outstanding balance]
    View --> Pay[Resident pays dues]
    Pay --> Credit[Credit posted to Ledger]
```

## Restrictions
- Residents can only view billing records belonging to their assigned unit. The selector is locked to the unit ID linked in their profile.
