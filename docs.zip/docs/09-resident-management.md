# Resident Management

Manages resident profiles, vehicles, and onboarding constraints.

## Vacancy Enforcement
- **Constraint**: When onboarding a resident, the dropdown only lists **vacant** units. Occupied units are hidden.
- **Rule**: If a resident moves out (`moved_out` status is flagged), their unit is automatically changed back to vacant.

## Vehicle Registration
Residents can register vehicles linked directly to their profile to enable guard checkpoint verification.
