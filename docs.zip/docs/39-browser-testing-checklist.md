# Browser Testing Checklist

Run these manual validation checks on the local build.

1. **Auth & Setup**: Verify sign-up does not display global admin options.
2. **Society Scopes**: Ensure Society Admins cannot assign `super_admin` to new users.
3. **Vacancy Checks**: Confirm that when adding a resident, occupied units are hidden.
