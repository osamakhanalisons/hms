# Property Hierarchy

The property module organizes housing structures into logical nested levels.

## Hierarchy Tree

```
Society (Tenant)
 ├── Block (Phase / Sector)
 │    ├── Building (Tower)
 │    │    ├── Floor (Vertical level)
 │    │    │    └── Unit (Apartment / Penthouse / Shop)
```

## Property APIs Scoping

- **API Endpoint**: `getPropertyTreeFn`
- **Tenant Validation**: The server filters the tree query on `tenant_id` derived from the user session.
- **Format Consistency**: Every unit selection field in forms displays the absolute path format: 
  `"Society Name › Block Name › Building Name › Unit Number"` to prevent naming collisions.
