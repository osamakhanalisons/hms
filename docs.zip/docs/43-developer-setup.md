# Developer Setup

Local developer installation steps.

1. Install dependencies: `npm install`
2. Configure `.env` file.
3. Boot development server: `npm run dev`
4. Run compiler validations: `npx tsc --noEmit`
