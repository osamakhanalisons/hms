# Database Architecture

Database design and integrity rules.

## Integrity Rules
- **Foreign Keys**: Cascade deletes are used for core relationships (e.g. deleting a user cleans up their session records).
- **Audit Logs**: Changes are tracked inside the `audit_logs` table to register mutations.
