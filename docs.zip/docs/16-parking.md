# Parking

Manages vehicle space allocation.

## Constraints
- Residents can view parking allocations but cannot create new parking slots.
- Allocations must validate slot ownership limits configured by the society admin.
- Multi-tenant isolation prevents slot indices from conflicting between societies.
