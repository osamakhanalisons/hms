# Community Forum

Interactive discussion board for verified residents.

## Workflow
Residents can create threads and reply to topics. Threads are scoped to the active tenant ID, ensuring conversations from Society A do not leak into Society B.
