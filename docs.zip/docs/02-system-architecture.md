# System Architecture

HousingOS is built on a modern server-side rendering architecture with robust API security boundaries.

## Architecture Flow

```mermaid
graph TD
    User([Browser Client])
    Vite([Vite / Vinxi Dev Server])
    Router([TanStack File Route])
    Gate([Module Gate Context])
    Fn([Vinxi Server Function])
    Auth([Auth Scoping Helper])
    DB[(MySQL Database)]

    User -->|HTTP Request| Vite
    Vite -->|Route Match| Router
    Router -->|Check Activation| Gate
    Gate -->|Execute Action| Fn
    Fn -->|Authorize User| Auth
    Auth -->|Tenant Isolated SQL| DB
    DB -->|Rows| Auth
    Auth -->|Data payload| User
```

## Backend Data Layer
All transactions occur via Vinxi Server Functions (defined using TanStack React Start's `createServerFn` wrapper). 
Requests contain user session tokens inside cookies, which are parsed server-side.

## State Management
- **Client Cache**: TanStack Query (`useQuery`, `useMutation`) with cached tenant queries.
- **Form Renderer**: Dynamic JSON forms mapped to `/forms` catalog schemas.
