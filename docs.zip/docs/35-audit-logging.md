# Audit Logging

Action tracking system.

## Log Targets
All modifications to roles, permissions, billing generations, and check-in overrides are logged under the `audit_logs` table with actor details, action types, and changes.
