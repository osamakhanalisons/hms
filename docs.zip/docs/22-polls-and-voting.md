# Polls & Voting

Society surveys and election voting.

## Constraints
- **Voter Eligibility**: Residents can cast exactly one vote per poll. Duplicate entries are blocked at database constraints level via unique index validations.
