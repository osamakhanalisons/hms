# Authentication & Sessions

Session management flows.

## Cookie Sessions
Authentication uses HttpOnly cookies to store `session_token`. The server validates this token against the `sessions` table on every request.

## Lockout Security
If a user inputs 5 consecutive incorrect passwords, their account is locked out for 15 minutes to prevent brute-force attacks.
