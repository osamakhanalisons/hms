# Society Lifecycle

## Lifecycle Flow

```mermaid
graph TD
    Create[Super Admin creates Tenant record] --> SetupAdmin[Assign Society Admin User]
    SetupAdmin --> SetupProp[Setup blocks, buildings, floors, units]
    SetupProp --> ActMod[Enable active modules]
    ActMod --> Onboard[Onboard residents & setup billing]
    Onboard --> Deact[Deactivate/Archive tenant modules]
```

- **Creation**: Handled exclusively by Super Admins on the `/societies` platform management page.
- **Deactivation**: Modules can be disabled at any time. When disabled, users attempting to access modules are blocked by the `ModuleGate` wrapper.
- **Permanent Delete**: Cascade-protected. Deleting a tenant fails if historical financial ledgers or active resident records are linked to prevent data loss.
