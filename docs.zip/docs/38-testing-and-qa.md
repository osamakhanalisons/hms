# Testing & QA Manual

QA validation protocols.

## Test Boundaries
- **Tenant boundaries**: Create a resident in Society A; verify they cannot access invoices from Society B.
- **Login security**: Verify account lockouts occur after 5 wrong attempts.
