# Events

Society event management.

## Workflow
Admins publish events (e.g. Independence Day, Annual Meeting). Residents RSVP directly via the event dashboard.
