# Maintenance

Handles work orders and maintenance scheduling.

## Technician Scoping
Technicians logged into the platform are redirected strictly to the maintenance tasks assigned to their user ID. They cannot view work orders of other blocks or housing societies.

## Preventative Triggers
- **Preventative Schedules**: Set up for recurring dates (e.g. monthly elevator inspections).
- **Status**: **PARTIALLY IMPLEMENTED**. Frontend scheduling is complete, but automation cron triggers must be verified in the backend daemon.
