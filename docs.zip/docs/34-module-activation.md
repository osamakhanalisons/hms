# Module Activation

Tenant feature flags.

- **Client Gate**: Renders the `ModuleGate` screen if the module key is not enabled for the tenant.
- **API Guard**: Backend functions execute checks using `getActiveModulesFn` to prevent disabled feature executions.
