# Amenities Booking

Reservation engine for shared resources (Gym, Pool, Clubhouse).

## Booking Collision Verification
- **Constraint**: The backend checks for timing overlaps on slots. Double-bookings are blocked, throwing an error if there is any overlap.
