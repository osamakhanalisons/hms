# Database Table Catalog

Exhaustive database table indexes.

## Core Security & Auth
- `users`: Authentication login credentials and email hashes.
- `profiles`: Personal contact details, linked with `tenant_id`.
- `user_roles`: User assigned roles mapping.
- `custom_roles`: Custom tenant roles created dynamically.
- `sessions`: Login session tokens and expiration datetimes.

## Tenant & Modules
- `tenants`: Society instances.
- `tenant_modules`: Active feature modules per tenant.
- `module_registry`: Global system modules list.
- `role_permissions`: RBAC dynamic override toggles.

## Property Model
- `societies`, `blocks`, `buildings`, `floors`, `units`

## Financials
- `charge_heads`, `ledger_entries`, `payments`, `wallets`
