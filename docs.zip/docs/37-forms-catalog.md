# Forms Catalog

The platform contains a built-in JSON form registry at `/forms` used to render pages dynamically. Submissions are processed inside `form_submissions`.
