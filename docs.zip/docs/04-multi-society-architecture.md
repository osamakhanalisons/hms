# Multi-Society Architecture

HousingOS supports multi-tenancy out of the box. Society Admins and Super Admins can manage multiple society contexts cleanly.

## Tenant Resolution

1. **Super Admin**:
   - Can select "All Societies" or pick a specific society from the top-left dropdown.
   - The selected society context is stored in the `selected_tenant_id` cookie.
   
2. **Society Admin**:
   - Assigned to one or more societies via the `society_admin_tenants` mapping table.
   - If assigned to multiple societies, the dropdown allows swapping between them.

3. **Scoping Helper (`getTenantScoping`)**:
   - Executed on every server function.
   - Derives the scoping SQL filters dynamically.
   - Ensures writes are mapped strictly to the authorized tenant context.

```mermaid
graph LR
    Cookie[selected_tenant_id Cookie] --> Scoping[getTenantScoping helper]
    Scoping -->|isSuperAdmin?| SA[1=1 / Scoped ID]
    Scoping -->|isSocietyAdmin?| Adm[Check society_admin_tenants mapping]
    Scoping -->|Resident/Other?| Res[Force profile.tenant_id match]
```
