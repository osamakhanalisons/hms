# User Management

Tenant-level users are created by authorized managers.

## Creation & Role Scoping
- **Endpoint**: `createTenantUserFn`
- **Constraint**: Society Admins cannot assign or create `super_admin` profiles.
- **Isolation**: Users are automatically linked to the active society ID stored in the administrator's scoping session context.

## Roles Allocation
Admins can assign multiple roles to a user. The user's maximum permissions are merged using an OR condition logic (most permissive logic wins).
