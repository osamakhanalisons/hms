# Known Issues & Gaps

Audit logs of current limitations.

- **Payment Gateways**: Stripe checkout is mock-only. No live transactions exist.
- **TypeScript Errors**: Unrelated API modules contain pre-existing syntax errors.
- **Cron Deactivations**: Module scheduling relies on manual triggers rather than backend workers.
