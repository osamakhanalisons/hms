# Troubleshooting Guide

Common runtime anomalies.

- **Database Connection Pool Exhaustion**: Occurs during rapid hot-reloads. Restart the dev server.
- **Scoping Errors**: Check if cookies are set correctly. Clearing storage resolves stale tenant mappings.
