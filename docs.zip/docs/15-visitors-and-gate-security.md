# Visitors & Gate Security

Secures gate check-ins and visitor logs.

## Visitor Pass Process

```mermaid
graph TD
    Res[Resident generates QR/Pass code] --> Pass[Pass sent to Visitor]
    Pass --> Gate[Visitor arrives at Gate]
    Gate --> Guard[Guard inputs code into gate portal]
    Guard --> Validate[Backend checks expiry & blacklists]
    Validate --> In[Check-in completed & entry logged]
```

- **Blacklist Alert**: If a phone number exists in the `visitor_blacklist` table, the guard terminal triggers a warning blocking check-in.
