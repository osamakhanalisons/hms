# Deployment & Environment

## Configuration requirements
- **Runtime**: Node.js v18.x
- **Database**: MySQL v8.0
- **Env**: Set `DATABASE_URL` and `SESSION_SECRET` inside `.env`.
