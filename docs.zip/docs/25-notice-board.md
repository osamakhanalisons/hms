# Notice Board

Official bulletin board for announcements.

## Scoping
Notices are published by the admin and display immediately on the resident dashboard upon activation.
