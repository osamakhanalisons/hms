# Vendors

Tracks external service providers and contracts.

## Status
- **PARTIALLY IMPLEMENTED**: Includes vendor registry and RFQ (Request For Quotation) creation. Quotation submission forms are currently mock designs.
