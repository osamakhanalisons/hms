# User Roles & Permissions

The platform supports pre-defined system roles and tenant-scoped custom roles.

## System Roles Directory

| Role Name (`role`) | Label | Scoping Level | Assignable in UI |
|---|---|---|---|
| `super_admin` | Super Admin | Platform-wide | No (Platform only) |
| `society_admin` | Society Admin | Tenant-wide | Yes (Within tenant) |
| `finance_head` | Finance Head | Tenant-wide | Yes |
| `maintenance_head`| Maintenance Head| Tenant-wide | Yes |
| `security_head` | Security Head | Tenant-wide | Yes |
| `resident` | Resident | Tenant-wide | Yes |
| `tenant` | Tenant | Tenant-wide | Yes |
| `guard` | Guard | Tenant-wide | Yes |
| `technician` | Technician | Tenant-wide | Yes |

### Custom Roles (`custom_roles` table)
Tenant admins can create custom roles (e.g., "Parking Manager"). These roles are strictly scoped to the tenant's ID and will not appear under other societies.

### Permission Mapping Rule
- **Assignment**: Decides *where* a user is authorized to perform changes (e.g., Society B).
- **Permission**: Decides *what* actions a user can run (e.g., `can_create` under ledger).
