# Complaints

Provides residents with a ticketing portal for maintenance requests.

## Workflow & Constraints
- **Isolation**: Residents can only view complaints submitted by themselves or linked to their own unit.
- **Kanban Board**: Staff and Admins manage tickets on a Kanban board spanning `open`, `assigned`, `in_progress`, `completed`, and `closed` columns.
- **Assignments**: Tickets can only be assigned to users with the `technician` role.
