# Inventory

Tracks stock levels of repair parts and materials.

## Workflow
Logs spare parts (pipes, light bulbs, valves). When a technician marks a work order as completed, inventory levels are decremented through stock movements.
