# RBAC Permissions

System actions authorization maps.

## Dynamic Overrides
System roles have built-in default permissions. If an override row exists in the `role_permissions` table, the server merges the custom rules using an override priority before determining access levels.
